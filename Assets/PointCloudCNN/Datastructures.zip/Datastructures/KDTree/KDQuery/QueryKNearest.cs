﻿/*MIT License

Copyright(c) 2018 Vili Volčini / viliwonka

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

using DataStructures.ViliWonka.Heap;
using Unity.Collections;
using Unity.Mathematics;
using Unity.Profiling;

namespace DataStructures.ViliWonka.KDTree {
	public class KnnQuery {
		int count; // size of queue
		KSmallestHeap<int> heap;
		MinHeap<KdQueryNode> minHeap; //heap for k-nearest
		
		KdQueryNode[] queueArray; // queue array

		int queryIndex; // current index at stack

		public KnnQuery(int k) {
			heap = new KSmallestHeap<int>(k);
			queueArray = new KdQueryNode[512 * 512];
			minHeap = new MinHeap<KdQueryNode>(512 * 512);
		}

		/// <summary>
		/// Returns initialized node from stack that also acts as a pool
		/// The returned reference to node stays in stack
		/// </summary>
		/// <returns>Reference to pooled node</returns>
		KdQueryNode PushGetQueue() {
			KdQueryNode node= queueArray[count];
			count++;
			return node;
		}

		void PushToHeap(KDNode node, float3 tempClosestPoint, float3 queryPosition) {
			KdQueryNode queryNode = PushGetQueue();
			
			queryNode.node = node;
			queryNode.tempClosestPoint = tempClosestPoint;
			
			float sqrDist = math.lengthsq(tempClosestPoint - queryPosition);
			queryNode.distance = sqrDist;
			
			minHeap.PushObj(queryNode, sqrDist);
		}

		static ProfilerMarker s_profMarker = new ProfilerMarker("KNNQuery");

		/// <summary>
		/// Returns indices to k closest points, and optionally can return distances
		/// </summary>
		/// <param name="tree">Tree to do search on</param>
		/// <param name="queryPosition">Position</param>
		/// <param name="resultIndices">List where resulting indices will be stored</param>
		public void KNearest(KDTree tree, float3 queryPosition, int[] resultIndices) {
			using (s_profMarker.Auto()) {
				heap.Clear();
				minHeap.Clear();

				count = 0;
				queryIndex = 0;

				var points = tree.Points;
				var permutation = tree.Permutation;

				KDNode rootNode = tree.RootNode;
				// Biggest Smallest Squared Radius
				float bssr = float.PositiveInfinity;

				float3 rootClosestPoint = rootNode.bounds.ClosestPoint(queryPosition);
				PushToHeap(rootNode, rootClosestPoint, queryPosition);

				// searching
				while (minHeap.Count > 0) {
					KdQueryNode queryNode = minHeap.PopObj();

					queueArray[queryIndex] = queryNode;
					queryIndex++;

					if (queryNode.distance > bssr) {
						continue;
					}

					KDNode node = queryNode.node;

					if (!node.Leaf) {
						int partitionAxis = node.partitionAxis;
						float partitionCoord = node.partitionCoordinate;

						float3 tempClosestPoint = queryNode.tempClosestPoint;

						if (tempClosestPoint[partitionAxis] - partitionCoord < 0) {
							// we already know we are on the side of negative bound/node,
							// so we don't need to test for distance
							// push to stack for later querying
							PushToHeap(node.negativeChild, tempClosestPoint, queryPosition);

							// project the tempClosestPoint to other bound
							tempClosestPoint[partitionAxis] = partitionCoord;

							if (node.positiveChild.Count != 0) {
								PushToHeap(node.positiveChild, tempClosestPoint, queryPosition);
							}
						} else {
							// we already know we are on the side of positive bound/node,
							// so we don't need to test for distance
							// push to stack for later querying
							PushToHeap(node.positiveChild, tempClosestPoint, queryPosition);

							// project the tempClosestPoint to other bound
							tempClosestPoint[partitionAxis] = partitionCoord;

							if (node.positiveChild.Count != 0) {
								PushToHeap(node.negativeChild, tempClosestPoint, queryPosition);
							}
						}
					} else {
						// LEAF
						for (int i = node.start; i < node.end; i++) {
							int index = permutation[i];
							float sqrDist = math.lengthsq(points[index] - queryPosition);

							if (sqrDist <= bssr) {
								heap.PushObj(index, sqrDist);

								if (heap.Full) {
									bssr = heap.HeadValue;
								}
							}
						}
					}
				}

				int retCount = heap.Count + 1;
				for (int i = 1; i < retCount; i++) {
					resultIndices[i - 1] = heap.PopObj();
				}
			}
		}
	}
}